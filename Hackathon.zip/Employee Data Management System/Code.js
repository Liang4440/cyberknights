function onOpen() {
  const ui = SpreadsheetApp.getUi();
  const menu = ui.createMenu('Admin');
  const menu1 = ui.createMenu('Event');

  menu.addItem('Edit employee', 'editEmployee');
  menu1.addItem('Send invitation', 'createCalendarEvent');
  menu1.addItem('Insert New Employees', 'copyDataToTargetSheet');

  menu.addToUi();
  menu1.addToUi();
}

function searchEmployee(id, sheetName) {
  const spreadS = SpreadsheetApp.getActiveSpreadsheet();
  const sheetN = spreadS.getSheetByName(sheetName);

  if (!sheetN) {
    throw new Error(`Sheet with name "${sheetName}" not found.`);
  }

  const textFinder = sheetN.createTextFinder(id);
  const cell = textFinder.findNext();

  if (!cell) {
    return null; // Employee ID not found
  }

  const row = cell.getRow();
  const rowData = sheetN.getRange(`A${row}:K${row}`).getValues()[0];

  return { row, rowData };
}

function editEmployee() {
  const ui = SpreadsheetApp.getUi();
  const empId = ui.prompt("Please enter employee id:");

  const button = empId.getSelectedButton();
  
  if (button === ui.Button.OK) {
    const id = empId.getResponseText();
    try {
      const employeeData = searchEmployee(id, "employeeTable");

      if (employeeData) {
        const htmlOutput = HtmlService.createHtmlOutputFromFile('EditEmployee')
            .setWidth(600)
            .setHeight(600);

        const replacements = {
          '{{Employee_ID}}': employeeData.rowData[0],
          '{{Emp_name}}': employeeData.rowData[1],
          '{{Email}}': employeeData.rowData[2],
          '{{Contact_number}}': employeeData.rowData[3],
          '{{Home_address}}': employeeData.rowData[4],
          '{{DOB}}': employeeData.rowData[5],
          '{{Gender}}': employeeData.rowData[6],
          '{{Department}}': employeeData.rowData[7],
          '{{Job_Title}}': employeeData.rowData[8],
          '{{Employment_Type}}': employeeData.rowData[9],
          '{{Employment_status}}': employeeData.rowData[10],
          '{{row}}': employeeData.row
        };

        let content = htmlOutput.getContent();
        for (const key in replacements) {
          content = content.replace(new RegExp(key, 'g'), replacements[key]);
        }
        htmlOutput.setContent(content);

        ui.showModalDialog(htmlOutput, 'Edit Employee Information');
      } else {
        ui.alert("Employee ID not found.");
      }
    } catch (error) {
      ui.alert(error.message);
    }
  } else {
    Logger.log("User cancelled the prompt.");
  }
}

function updateEmployee(data) {
  const { row, Emp_name, Email, Contact_number, Home_address, DOB, Gender, Department, Job_Title, Employment_Type, Employment_status } = data;
  UpdateRecord(row, Emp_name, Email, Contact_number, Home_address, DOB, Gender, Department, Job_Title, Employment_Type, Employment_status);
}

function UpdateRecord(rowIndex, name, email, cNumber, address, dob, gender, department, jTitle, empType, empStatus) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const recordSheet = ss.getSheetByName("employeeTable");
  
  recordSheet.getRange(rowIndex, 2, 1, 10).setValues([[name, email, cNumber, address, dob, gender, department, jTitle, empType, empStatus]]);
}

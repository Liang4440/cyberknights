function createCalendarEvent() {
  let events = SpreadsheetApp.getActiveSpreadsheet().getRangeByName("events").getValues();

  events.forEach(function(e) {
    var stage = e[8];

    if (stage !== "Interviewing") {
      return;
    }

    var calendar = CalendarApp.getCalendarById("c_5f6eac3dd769e4fe649b2f23c698918385485b663c082e9e1b3a53d92bb003ca@group.calendar.google.com");
    var event = calendar.createEvent(
      "Interview Invitation: " + e[1],
      new Date(e[10]),
      new Date(e[11]),
      {
        description: "Interviewer: " + e[9],
        guests: e[2], // Assuming guests are in a comma-separated list
        sendInvites: true
      }
    );
  });
}

function copyDataToTargetSheet() {
  let spreadSheet = SpreadsheetApp.getActiveSpreadsheet();
  let sourceSheet = spreadSheet.getSheetByName('interviewList');
  
  // Get the entire data range from the source sheet
  let dataRange = sourceSheet.getDataRange();
  let dataValues = dataRange.getValues();

  let targetSheet = spreadSheet.getSheetByName('employeeTable');
  
  // Get the data range and values from the target sheet
  let targetDataRange = targetSheet.getDataRange();
  let targetValues = targetDataRange.getValues();

  // Define an array to hold the filtered rows
  let filteredValues = [];

  // Iterate through the data and filter rows where column I (index 8) equals "add"
  for (let i = 0; i < dataValues.length; i++) {
    if (dataValues[i][8] === "add") {
      // Only include columns B to G (indices 1 to 6)
      filteredValues.push(dataValues[i].slice(1, 7));

      // Update the status to "Hire"
      dataValues[i][8] = "Hire";
    }
  }

  // Update the source sheet with the new status
  sourceSheet.getRange(1, 1, dataValues.length, dataValues[0].length).setValues(dataValues);

  if (filteredValues.length > 0) {
    filteredValues.forEach(rowData => {
      // Check if there's an empty cell in the second column of any existing row
      let inserted = false;
      for (let rowIndex = 1; rowIndex < targetValues.length; rowIndex++) {
        if (targetValues[rowIndex][1] === '') {
          // If the second column of this row is empty, insert data here
          targetSheet.getRange(rowIndex + 1, 2, 1, rowData.length).setValues([rowData]);
          inserted = true;
          break;
        }
      }

      // If no empty cell was found, append the data at the bottom
      if (!inserted) {
        targetSheet.appendRow([''].concat(rowData)); // Append with an empty value in the first column
      }
    });
  }

  Logger.log('Data copied successfully from interviewList to employeeTable');
}




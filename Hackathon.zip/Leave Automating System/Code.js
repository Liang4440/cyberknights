function onFormSubmit(e) {
  var formResponsesSheetName = 'Form Responses 1'; // Ensure this matches your form response sheet name
  var trackingSheetName = 'Leave Request'; // Ensure this matches your tracking sheet name

  // Get the active spreadsheet
  var spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  Logger.log("Active spreadsheet: " + spreadsheet.getName());

  // Get the form response sheet
  var sheet = spreadsheet.getSheetByName(formResponsesSheetName);
  if (!sheet) {
    Logger.log("Form response sheet not found: " + formResponsesSheetName);
    return;
  }

  var row = sheet.getLastRow();
  var data = sheet.getRange(row, 1, 1, sheet.getLastColumn()).getValues()[0];
  Logger.log("Form response data: " + data);

  var timestamp = data[0];
  var employeeName = data[1];
  var employeeEmail = data[2];
  var leaveType = data[3];
  var startDate = new Date(data[4]);
  var endDate = new Date(data[5]);
  var reason = data[6];
  var status = "Pending";
  var approverEmail = "chaihuasheng@gmail.com"; // Replace with the approver's email
  var comments = "";

  // Log retrieved email to ensure it's correct
  Logger.log("Employee Email: " + employeeEmail);

  // Check if employee email is valid
  if (!employeeEmail) {
    Logger.log("No employee email provided");
    return; // Exit the function if no email is provided
  }

  // Get the leave requests tracking sheet
  var trackingSheet = spreadsheet.getSheetByName(trackingSheetName);
  if (!trackingSheet) {
    Logger.log("Tracking sheet not found: " + trackingSheetName);
    return;
  }
  Logger.log("Tracking sheet found: " + trackingSheet.getName());

  // Append the new leave request to the tracking sheet
  trackingSheet.appendRow([timestamp, employeeName, employeeEmail, leaveType, startDate, endDate, reason, status, approverEmail, comments]);

  // Send approval email to the approver
  sendApprovalEmail(employeeName, employeeEmail, leaveType, startDate, endDate, reason, approverEmail);

  var calendarId = "c88fbb133b5079691394526aa9672144be327531938613d3ed3f7b4c70d6f281@group.calendar.google.com"; // Replace with your actual Calendar ID
  Logger.log("Using Calendar ID: " + calendarId);
  createCalendarEvent(calendarId, employeeName, leaveType, startDate, endDate, reason);
}

function sendApprovalEmail(employeeName, employeeEmail, leaveType, startDate, endDate, reason, approverEmail) {
  var subject = "Leave Request Approval Needed";
  var body = "A new leave request has been submitted by " + employeeName + " (" + employeeEmail + ").\n\n" +
             "Leave Type: " + leaveType + "\n" +
             "Start Date: " + startDate + "\n" +
             "End Date: " + endDate + "\n" +
             "Reason: " + reason + "\n\n" +
             "Please review and take appropriate action.";

  Logger.log("Sending approval email to: " + approverEmail);
  MailApp.sendEmail(approverEmail, subject, body);
}

function sendEmployeeEmail(employeeName, employeeEmail, leaveType, startDate, endDate, reason, status) {
  var subject = "Leave Request Submitted";

  var message = "Dear " + employeeName + ",\n\n" +
                "Your leave request has been submitted successfully with the following details:\n\n" +
                "Leave Type: " + leaveType + "\n" +
                "Start Date: " + startDate + "\n" +
                "End Date: " + endDate + "\n" +
                "Reason: " + reason + "\n" +
                "Status: " + status + "\n\n" +
                "You will be notified once your leave request is reviewed and approved/denied.\n\n" +
                "Best regards,\n" +
                "HR Department";

  var htmlMessage = "<p>Dear " + employeeName + ",</p>" +
                    "<p>Your leave request has been submitted successfully with the following details:</p>" +
                    "<ul>" +
                    "<li><strong>Leave Type:</strong> " + leaveType + "</li>" +
                    "<li><strong>Start Date:</strong> " + startDate + "</li>" +
                    "<li><strong>End Date:</strong> " + endDate + "</li>" +
                    "<li><strong>Reason:</strong> " + reason + "</li>" +
                    "<li><strong>Status:</strong> " + status + "</li>" +
                    "</ul>" +
                    "<p>You will be notified once your leave request is reviewed and approved/denied.</p>" +
                    "<p>Best regards,<br>HR Department</p>";

  Logger.log("Sending confirmation email to: " + employeeEmail);
  MailApp.sendEmail({
    to: employeeEmail,
    subject: subject,
    htmlBody: htmlMessage,
    body: message
  });
}

function createCalendarEvent(calendarId, employeeName, leaveType, startDate, endDate, reason) {
  Logger.log("Attempting to access calendar with ID: " + calendarId);
  var calendar = CalendarApp.getCalendarById(calendarId);
  if (!calendar) {
    Logger.log("Calendar not found: " + calendarId);
    return;
  }
  Logger.log("Calendar found: " + calendarId);

  var eventTitle = leaveType + " Leave: " + employeeName;
  var eventOptions = {
    description: reason
  };

  Logger.log("Creating event with title: " + eventTitle);
  calendar.createEvent(eventTitle, startDate, endDate, eventOptions);
  Logger.log("Event created successfully: " + eventTitle);
}

function sendApprovalEmail(employeeName, employeeEmail, leaveType, startDate, endDate, reason, approverEmail) {
  var subject = "Leave Request Approval Needed";
  var body = "A leave request has been submitted by " + employeeName + ".\n\n" +
             "Leave Type: " + leaveType + "\n" +
             "Start Date: " + startDate + "\n" +
             "End Date: " + endDate + "\n" +
             "Reason: " + reason + "\n\n" +
             "Please review and approve the request.";
  MailApp.sendEmail(approverEmail, subject, body);
}

function sendEmployeeEmail(employeeName, employeeEmail, leaveType, startDate, endDate, reason, status) {
  var subject = "Leave Request Submission Confirmation";
  var body = "Dear " + employeeName + ",\n\n" +
             "Your leave request has been submitted successfully.\n\n" +
             "Leave Type: " + leaveType + "\n" +
             "Start Date: " + startDate + "\n" +
             "End Date: " + endDate + "\n" +
             "Reason: " + reason + "\n" +
             "Status: " + status + "\n\n" +
             "You will be notified once your request is reviewed.";
  MailApp.sendEmail(employeeEmail, subject, body);
}


function sendApprovalEmail(employeeName, employeeEmail, leaveType, startDate, endDate, reason, approverEmail) {
  var subject = "Leave Request Approval Needed";
  var body = "A new leave request has been submitted by " + employeeName + " (" + employeeEmail + ").\n\n" +
             "Leave Type: " + leaveType + "\n" +
             "Start Date: " + startDate + "\n" +
             "End Date: " + endDate + "\n" +
             "Reason: " + reason + "\n\n" +
             "Please review and take appropriate action.";

  Logger.log("Sending approval email to: " + approverEmail);
  MailApp.sendEmail(approverEmail, subject, body);
}

function sendNotificationEmail(employeeEmail, employeeName, leaveType, startDate, endDate, reason, status) {
  if (!employeeEmail) {
    Logger.log("No recipient email provided.");
    return;
  }

  var subject = "Leave Request " + status;

  var message = "Dear " + employeeName + ",\n\n" +
                "Your leave request has been " + status + " with the following details:\n\n" +
                "Leave Type: " + leaveType + "\n" +
                "Start Date: " + startDate + "\n" +
                "End Date: " + endDate + "\n" +
                "Reason: " + reason + "\n\n" +
                "Best regards,\n" +
                "HR Department";

  var htmlMessage = "<p>Dear " + employeeName + ",</p>" +
                    "<p>Your leave request has been <strong>" + status + "</strong> with the following details:</p>" +
                    "<ul>" +
                    "<li><strong>Leave Type:</strong> " + leaveType + "</li>" +
                    "<li><strong>Start Date:</strong> " + startDate + "</li>" +
                    "<li><strong>End Date:</strong> " + endDate + "</li>" +
                    "<li><strong>Reason:</strong> " + reason + "</li>" +
                    "</ul>" +
                    "<p>Best regards,<br>HR Department</p>";

  Logger.log("Sending email to: " + employeeEmail);
  MailApp.sendEmail({
    to: employeeEmail,
    subject: subject,
    htmlBody: htmlMessage,
    body: message
  });
}

function showEmailSidebar() {
  var html = HtmlService.createHtmlOutputFromFile('emailSidebar')
    .setTitle('Send Email to Employee');
  SpreadsheetApp.getUi().showSidebar(html);
}

function sendEmployeeEmail(formData) {
  var employeeEmail = formData.employeeEmail;
  var employeeName = formData.employeeName;
  var leaveType = formData.leaveType;
  var startDate = formData.startDate;
  var endDate = formData.endDate;
  var reason = formData.reason;
  var status = formData.status;

  var subject = "Leave Request Submitted";
  
  var message = "Dear " + employeeName + ",\n\n" +
                "Your leave request has been submitted successfully with the following details:\n\n" +
                "Leave Type: " + leaveType + "\n" +
                "Start Date: " + startDate + "\n" +
                "End Date: " + endDate + "\n" +
                "Reason: " + reason + "\n" +
                "Status: " + status + "\n\n" +
                "You will be notified once your leave request is reviewed and approved/denied.\n\n" +
                "Best regards,\n" +
                "HR Department";

  var htmlMessage = "<p>Dear " + employeeName + ",</p>" +
                    "<p>Your leave request has been submitted successfully with the following details:</p>" +
                    "<ul>" +
                    "<li><strong>Leave Type:</strong> " + leaveType + "</li>" +
                    "<li><strong>Start Date:</strong> " + startDate + "</li>" +
                    "<li><strong>End Date:</strong> " + endDate + "</li>" +
                    "<li><strong>Reason:</strong> " + reason + "</li>" +
                    "<li><strong>Status:</strong> " + status + "</li>" +
                    "</ul>" +
                    "<p>You will be notified once your leave request is reviewed and approved/denied.</p>" +
                    "<p>Best regards,<br>HR Department</p>";

  MailApp.sendEmail({
    to: employeeEmail,
    subject: subject,
    htmlBody: htmlMessage,
    body: message
  });
}

function onOpen() {
  var ui = SpreadsheetApp.getUi();
  ui.createMenu('HR Management')
    .addItem('Update Leave Summary', 'updateLeaveSummary')
    .addItem('Clear Leave Data', 'clearLeaveData')
    .addToUi();
  ui.createMenu('Leave Management')
    .addItem('Approve Selected Leave', 'approveLeave')
    .addItem('Deny Selected Leave', 'denyLeave')
    .addToUi();
  ui.createMenu('Employee Management')
    .addItem('Send Email to Employee', 'showEmailSidebar')
    .addToUi();
}

function approveLeave() {
  updateLeaveStatus('Approved');
}

function denyLeave() {
  updateLeaveStatus('Denied');
}

function updateLeaveStatus(status) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Leave Request');
  if (!sheet) {
    Logger.log("Leave Request sheet not found");
    return;
  }
  
  var range = sheet.getActiveRange();
  var rows = range.getNumRows();
  var startRow = range.getRow();
  var statusColumn = 8; // Assuming status is in the 8th column

  for (var i = 0; i < rows; i++) {
    var row = startRow + i;
    var employeeEmail = sheet.getRange(row, 3).getValue(); // Assuming email is in the 3rd column
    var employeeName = sheet.getRange(row, 2).getValue(); // Assuming name is in the 2nd column
    var leaveType = sheet.getRange(row, 4).getValue(); // Assuming leave type is in the 4th column
    var startDate = sheet.getRange(row, 5).getValue(); // Assuming start date is in the 5th column
    var endDate = sheet.getRange(row, 6).getValue(); // Assuming end date is in the 6th column
    var reason = sheet.getRange(row, 7).getValue(); // Assuming reason is in the 7th column

    Logger.log("Row: " + row + ", Email: " + employeeEmail + ", Name: " + employeeName + ", Leave Type: " + leaveType + ", Start Date: " + startDate + ", End Date: " + endDate + ", Reason: " + reason + ", Status: " + status);

    if (employeeEmail) {
      sheet.getRange(row, statusColumn).setValue(status);
      sendNotificationEmail(employeeEmail, employeeName, leaveType, startDate, endDate, reason, status);
    } else {
      Logger.log("No email found for row: " + row);
    }
  }
}

function countTotalEmployeesAppliedForLeave() {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Leave Request');
  var data = sheet.getRange(2, 3, sheet.getLastRow() - 1, 1).getValues(); // Column C
  var uniqueEmployees = new Set();
  
  for (var i = 0; i < data.length; i++) {
    if (data[i][0]) {
      uniqueEmployees.add(data[i][0]);
    }
  }
  
  Logger.log("Total employees applied for leave: " + uniqueEmployees.size);
  return uniqueEmployees.size;
}

function countEmployeesCurrentlyOnLeave() {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Leave Request');
  var data = sheet.getRange(2, 8, sheet.getLastRow() - 1, 1).getValues(); // Column H
  var count = 0;
  
  for (var i = 0; i < data.length; i++) {
    if (data[i][0] === "Approved") {
      count++;
    }
  }
  
  Logger.log("Total employees currently on leave: " + count);
  return count;
}

function clearLeaveData() {
  var spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  var leaveSheet = spreadsheet.getSheetByName('Leave Request');

  if (!leaveSheet) {
    Logger.log("Leave Request sheet not found");
    return;
  }

  // Clear the contents of the leave data range
  // Assuming that your leave data starts from row 2 and spans columns A to J
  leaveSheet.getRange(2, 1, leaveSheet.getLastRow() - 1, 10).clearContent();

  Logger.log("Leave data cleared successfully");
}

function updateLeaveSummary() {
  var spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  var leaveSheet = spreadsheet.getSheetByName('Leave Request');
  var summarySheet = spreadsheet.getSheetByName('Attendance Summary');

  if (!leaveSheet) {
    Logger.log("Leave Requests sheet not found");
    return;
  }

  if (!summarySheet) {
    Logger.log("Summary sheet not found");
    return;
  }

  Logger.log("Leave Requests sheet found: " + leaveSheet.getName());
  Logger.log("Summary sheet found: " + summarySheet.getName());

  // Get all leave data
  var leaveDataRange = leaveSheet.getRange(2, 3, leaveSheet.getLastRow() - 1, 1);
  var leaveData = leaveDataRange.getValues();

  // Create an object to store unique employee counts
  var uniqueEmployees = new Set();

  for (var i = 0; i < leaveData.length; i++) {
    if (leaveData[i][0]) {
      uniqueEmployees.add(leaveData[i][0]);
    }
  }
  var totalAppliedForLeave = uniqueEmployees.size;

  // Get status data
  var statusDataRange = leaveSheet.getRange(2, 8, leaveSheet.getLastRow() - 1, 1);
  var statusData = statusDataRange.getValues();

  var countCurrentlyOnLeave = 0;

  for (var j = 0; j < statusData.length; j++) {
    if (statusData[j][0] === "Approved") {
      countCurrentlyOnLeave++;
    }
  }

  Logger.log("Total employees applied for leave: " + totalAppliedForLeave);
  Logger.log("Total employees currently on leave: " + countCurrentlyOnLeave);

  // Update Summary Sheet
  summarySheet.getRange('A1').setValue('Total Employees Applied for Leave');
  summarySheet.getRange('B1').setValue(totalAppliedForLeave);

  summarySheet.getRange('A2').setValue('Total Employees Currently on Leave');
  summarySheet.getRange('B2').setValue(countCurrentlyOnLeave);
}






